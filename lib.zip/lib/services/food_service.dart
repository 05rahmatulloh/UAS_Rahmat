import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:mobileuts/model/food_model.dart';

class FoodService {
  static const String baseUrl = 'https://coba1-5f863-default-rtdb.asia-southeast1.firebasedatabase.app/UAS/.json';

  static Future<List<Food>> fetchFoods() async {
    try {
      final response = await http.get(Uri.parse(baseUrl));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);

        // Mapping setiap entry menjadi list Food
        List<Food> foods = [];
        data.forEach((key, value) {
          foods.add(Food.fromJson(value));
        });

        return foods;
      } else {
        print("Failed to fetch data. Status code: ${response.statusCode}");
        return [];
      }
    } catch (e) {
      print("Error fetching foods: $e");
      return [];
    }
  }
}
